/*
import 'package:flutter_bloc/flutter_bloc.dart';
import '../Provider/rest_provider.dart';
import '../Model/note.dart';

class ManageBloc extends Bloc<ManageEvent, ManageState> {
  ManageBloc() : super(InsertState(noteList: [])) {
    on<SubmitEvent>((event, emit) async {
      if (event.isUpdate) {
        await RestProvider.helper.updateNote(event.note.noteId, event.note);
      } else {
        await RestProvider.helper.insertNote(event.note);
      }
      List<Note> noteList = await RestProvider.helper.getNoteList();
      emit(InsertState(noteList: noteList));
    });
    on<DeleteEvent>((event, emit) async {
      await RestProvider.helper.deleteNote(event.noteId);
      List<Note> noteList = await RestProvider.helper.getNoteList();
      emit(InsertState(noteList: noteList));
    });
    on<GetNoteList>(
      (event, emit) async {
        List<Note> noteList = await RestProvider.helper.getNoteList();
        emit(InsertState(noteList: noteList));
      },
    );
    on<EmptyListEvent>(
      (event, emit) {
        emit(InsertState(noteList: []));
      },
    );
    on<UpdateRequest>((event, emit) {
      emit(UpdateState(
        noteId: event.noteId,
        noteList: state.noteList,
      ));
    });

    on<UpdateCancel>((event, emit) {
      emit(InsertState(
        noteList: state.noteList,
      ));
    });
  }
}

abstract class ManageEvent {}

class SubmitEvent extends ManageEvent {
  Note note;
  final bool isUpdate;
  SubmitEvent({required this.note, this.isUpdate = false});
}

class UpdateEvent extends ManageEvent {
  String noteId;
  Note note;
  UpdateEvent({required this.noteId, required this.note});
}

class DeleteEvent extends ManageEvent {
  String noteId;
  DeleteEvent({required this.noteId});
}

class GetNoteList extends ManageEvent {}

class UpdateRequest extends ManageEvent {
  String noteId;
  UpdateRequest({required this.noteId});
}

class UpdateCancel extends ManageEvent {}

class EmptyListEvent extends ManageEvent {}

abstract class ManageState {
  List<Note> noteList;

  ManageState({required this.noteList});
}

class InsertState extends ManageState {
  InsertState({required super.noteList});
}

class UpdateState extends ManageState {
  String noteId;
  UpdateState({
    required this.noteId,
    required super.noteList,
  });
}
import 'package:flutter_bloc/flutter_bloc.dart';

enum AuthStatus { authenticated, unauthenticated }

class AuthBloc extends Bloc<AuthEvent, AuthStatus> {
  AuthBloc() : super(AuthStatus.unauthenticated) {
    on<ToggleAuthEvent>((event, emit) {
      if (state == AuthStatus.authenticated) {
        emit(AuthStatus.unauthenticated);
      } else {
        emit(AuthStatus.authenticated);
      }
    });
  }
}

abstract class AuthEvent {}

class ToggleAuthEvent extends AuthEvent {}

import 'package:trabalho_1_mobile/Model/note.dart';
import 'package:dio/dio.dart';

class RestProvider {
  static RestProvider helper = RestProvider._createInstance();

  String suffixUrl = '.json';
  String prefixUrl = 'https://trabalho-1-92856-default-rtdb.firebaseio.com/';

  String uid = "public";

  RestProvider._createInstance();
  Dio dio = Dio();

  Future<Note> getNote(String noteId) async {
    Response response = await dio.get("$prefixUrl/$noteId$suffixUrl");
    return Note.fromMap(response.data);
  }

  Future<int> insertNote(Note note) async {
    Response response = await dio.post(
      prefixUrl + suffixUrl,
      data: note.toMap(),
    );
    return int.parse(response.data['id'].toString());
  }

  Future<int> updateNote(String noteId, Note note) async {
    await dio.put(
      "$prefixUrl/$noteId$suffixUrl",
      data: note.toMap(),
    );
    return 42;
  }

  Future<int> deleteNote(String noteId) async {
    await dio.delete("$prefixUrl/$noteId$suffixUrl");
    return 42;
  }

  Future<List<Note>> getNoteList() async {
    Response response = await dio.get(prefixUrl + suffixUrl);
    List<Note> noteCollection = [];

    response.data.forEach((key, value) {
      Note note = Note.fromMap(value);
      note.noteId = key;
      noteCollection.add(note);
    });
    return noteCollection;
  }
}
import 'package:flutter_bloc/flutter_bloc.dart';

// 2. Definir o Enum ProfileState:
enum ProfileState { admin, user, guest }

// 3. Implementar a Classe ProfileBloc:
class ProfileBloc extends Bloc<ProfileEvent, ProfileState> {
  ProfileBloc() : super(ProfileState.guest) {
    on<SetAdminProfileEvent>((event, emit) {
      emit(ProfileState.admin);
    });
    on<SetUserProfileEvent>((event, emit) {
      emit(ProfileState.user);
    });
    on<SetGuestProfileEvent>((event, emit) {
      emit(ProfileState.guest);
    });
  }
}

abstract class ProfileEvent {}

class SetAdminProfileEvent extends ProfileEvent {}

class SetUserProfileEvent extends ProfileEvent {}

class SetGuestProfileEvent extends ProfileEvent {}

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:trabalho_1_mobile/Model/note.dart';
import 'package:trabalho_1_mobile/Provider/rest_provider.dart';

/*
   Eventos
*/
abstract class AuthEvent {}

class RegisterUser extends AuthEvent {
  final Note note;

  RegisterUser({required this.note});
}

class LoginUser extends AuthEvent {
  final String email;
  final String senha;

  LoginUser({required this.email, required this.senha});
}

class LoginAnonymousUser extends AuthEvent {}

class Logout extends AuthEvent {}

class AuthServerEvent extends AuthEvent {
  final String? userModel;

  AuthServerEvent(this.userModel);
}

/*
   Estados
*/
abstract class AuthState {}

class Unauthenticated extends AuthState {}

class Authenticated extends AuthState {
  final String userModel;

  Authenticated({required this.userModel});
}

class AuthError extends AuthState {
  final String message;

  AuthError({required this.message});
}

/*
   Bloc
*/
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  AuthBloc() : super(Unauthenticated()) {
    on<AuthServerEvent>((event, emit) {
      if (event.userModel == null) {
        RestProvider.helper.uid = "public";
        emit(Unauthenticated());
      } else {
        RestProvider.helper.uid = event.userModel!;
        emit(Authenticated(userModel: event.userModel!));
      }
    });

    /*on<RegisterUser>((event, emit) async {
      try {
        print(event.note.toMap());
        String? userId = await RestProvider.helper.registerUser(event.note);
        if (userId != null) {
          RestProvider.helper.insertNote(event.note);
          emit(Authenticated(userModel: userId));
        }
      } catch (e) {
        RestProvider.helper.uid = "public";
        emit(AuthError(message: "Impossível Registrar: ${e.toString()}"));
      }
    });*/
    on<RegisterUser>((event, emit) async {
      try {
        print('Tentando registrar usuário com email: ${event.note.email}');
        String? userId = await RestProvider.helper
            .registerUser(event.note);
        print('Valor de userId retornado: $userId');

        if (userId != null) {
          String logMessage = 'Usuário registrado com sucesso, userId: $userId';
          print(logMessage);
          await RestProvider.helper.insertNote(event.note);
          emit(Authenticated(userModel: userId));
        } else {
          print('Falha ao registrar usuário, userId é nulo');
          emit(AuthError(message: "Falha ao registrar usuário, userId é nulo"));
        }
      } catch (e) {
        print('Erro ao registrar usuário: $e');
        RestProvider.helper.uid = "public";
        emit(AuthError(message: "Impossível Registrar: ${e.toString()}"));
      }
    });

    on<LoginUser>((event, emit) async {
      try {
        String? userId =
            await RestProvider.helper.loginUser(event.email, event.senha);
        if (userId != null) {
          emit(Authenticated(userModel: userId));
        }
      } catch (e) {
        RestProvider.helper.uid = "public";
        emit(AuthError(
            message: "Impossível Logar com ${event.email}: ${e.toString()}"));
      }
    });

    on<Logout>((event, emit) async {
      try {
        await RestProvider.helper.logoutUser();
        emit(Unauthenticated());
      } catch (e) {
        RestProvider.helper.uid = "public";
        emit(AuthError(message: "Impossível Efetuar Logout: ${e.toString()}"));
      }
    });
  }
}
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import '../Model/note.dart';

class RestProvider {
  static final RestProvider helper = RestProvider._createInstance();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _dbRef = FirebaseDatabase.instance.reference();
  String uid = "public";
  RestProvider._createInstance();

  Future<Note> getNote(String noteId) async {
    try {
      DatabaseReference noteRef = _dbRef.child(noteId);
      DatabaseEvent event = await noteRef.once();
      DataSnapshot snapshot = event.snapshot;
      return Note.fromMap(Map<String, dynamic>.from(snapshot.value as Map));
    } catch (e) {
      print("Erro ao obter nota: $e");
      rethrow;
    }
  }

  Future<void> insertNote(Note note) async {
    try {
      await _dbRef.push().set(note.toMap());
    } catch (e) {
      print("Erro ao inserir nota: $e");
      rethrow;
    }
  }

  Future<void> updateNote(String noteId, Note note) async {
    try {
      await _dbRef.child(noteId).update(note.toMap());
    } catch (e) {
      print("Erro ao atualizar nota: $e");
      rethrow;
    }
  }

  Future<void> deleteNote(String noteId) async {
    try {
      await _dbRef.child(noteId).remove();
    } catch (e) {
      print("Erro ao deletar nota: $e");
      rethrow;
    }
  }

  Future<List<Note>> getNoteList() async {
    try {
      DatabaseEvent event = await _dbRef.once();
      DataSnapshot snapshot = event.snapshot;
      List<Note> noteList = [];
      Map<String, dynamic> notesMap =
          Map<String, dynamic>.from(snapshot.value as Map);
      notesMap.forEach((key, value) {
        Note note = Note.fromMap(Map<String, dynamic>.from(value as Map));
        note.noteId = key;
        noteList.add(note);
      });
      return noteList;
    } catch (e) {
      print("Erro ao obter lista de notas: $e");
      rethrow;
    }
  }

  Future<String?> registerUser(Note note) async {
    try {
      print("chegando");
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: note.email,
        password: note.senha,
      );
      print("Usuário registrado com UID: ${userCredential.user?.uid}");
      return userCredential.user?.uid;
    } catch (e) {
      print("Erro ao registrar usuário: $e");
      throw Exception("Erro ao registrar usuário: $e");
    }
  }

  Future<String?> loginUser(String email, String password) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      print("Usuário logado com UID: ${userCredential.user?.uid}");
      return userCredential.user?.uid;
    } catch (e) {
      print("Erro ao logar usuário: $e");
      throw Exception("Erro ao logar usuário: $e");
    }
  }

  Future<void> logoutUser() async {
    try {
      await _auth.signOut();
      print("Usuário deslogado com sucesso");
    } catch (e) {
      print("Erro ao deslogar usuário: $e");
      throw Exception("Erro ao deslogar usuário: $e");
    }
  }
}

*/
