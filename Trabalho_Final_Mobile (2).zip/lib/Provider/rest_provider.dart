import 'package:trabalho_1_mobile/Model/note.dart';
import 'package:dio/dio.dart';

class RestProvider {
  static RestProvider helper = RestProvider._createInstance();

  String suffixUrl = '.json';
  String prefixUrl = 'https://trabalho-1-92856-default-rtdb.firebaseio.com/';

  String uid = "public";

  RestProvider._createInstance();
  Dio dio = Dio();

  Future<Note> getNote(String noteId) async {
    Response response = await dio.get("$prefixUrl/$noteId$suffixUrl");
    return Note.fromMap(response.data);
  }

  Future<int> insertNote(Note note) async {
    Response response = await dio.post(
      prefixUrl + suffixUrl,
      data: note.toMap(),
    );
    return int.parse(response.data['id'].toString());
  }

  Future<int> updateNote(String noteId, Note note) async {
    await dio.put(
      "$prefixUrl/$noteId$suffixUrl",
      data: note.toMap(),
    );
    return 42;
  }

  Future<int> deleteNote(String noteId) async {
    await dio.delete("$prefixUrl/$noteId$suffixUrl");
    return 42;
  }

  Future<List<Note>> getNoteList() async {
    Response response = await dio.get(prefixUrl + suffixUrl);
    List<Note> noteCollection = [];

    response.data.forEach((key, value) {
      Note note = Note.fromMap(value);
      note.noteId = key;
      noteCollection.add(note);
    });
    return noteCollection;
  }
}
