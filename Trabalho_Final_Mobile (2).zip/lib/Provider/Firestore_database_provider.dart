import 'package:cloud_firestore/cloud_firestore.dart';
import '../Model/note.dart';

class FirestoreDatabaseProvider {
  static FirestoreDatabaseProvider helper =
      FirestoreDatabaseProvider._createInstance();

  String uid = "public";

  FirestoreDatabaseProvider._createInstance();

  final CollectionReference noteCollection =
      FirebaseFirestore.instance.collection("notes");

  Future<Note> getNote(String noteId) async {
    DocumentSnapshot doc =
        await noteCollection.doc(uid).collection("my_notes").doc(noteId).get();
    return Note.fromMap(doc.data());
  }

  Future<String> insertNote(Note note) async {
    DocumentReference doc =
        await noteCollection.doc(uid).collection("my_notes").add(note.toMap());
    return doc.id;
  }

  Future<String> updateNote(String noteId, Note note) async {
    DocumentReference doc = noteCollection
        .doc(
          uid,
        )
        .collection("my_notes")
        .doc(noteId);
    await doc.update(note.toMap());
    return doc.id;
  }

  Future<String> deleteNote(String noteId) async {
    DocumentReference doc = noteCollection
        .doc(
          uid,
        )
        .collection("my_notes")
        .doc(noteId);
    await doc.delete();
    return doc.id;
  }

  Future<List<Note>> getNoteList() async {
    CollectionReference myCollection = noteCollection
        .doc(
          uid,
        )
        .collection("my_notes");
    QuerySnapshot myQuery = await myCollection.get();

    List<Note> myNoteCollection = [];
    for (var doc in myQuery.docs) {
      myNoteCollection.add(Note.fromMap(doc.data()));
    }
    return myNoteCollection;
  }
}
