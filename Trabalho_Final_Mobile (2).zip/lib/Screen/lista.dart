// ignore_for_file: prefer_const_constructors, library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:trabalho_1_mobile/Screen/update_Screen.dart';
import '../bloc/manage_bloc.dart';
import '../Model/note.dart';

class Lista extends StatefulWidget {
  const Lista({Key? key}) : super(key: key);

  @override
  _ListaState createState() => _ListaState();
}

class _ListaState extends State<Lista> {
  final List icons = [Icons.edit];
  @override
  void initState() {
    super.initState();
    BlocProvider.of<ManageBloc>(context).add(GetNoteList());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ManageBloc, ManageState>(
      builder: (context, state) {
        BlocProvider.of<ManageBloc>(context).add(GetNoteList());
        List<Note> noteList = [];
        if (state is InsertState || state is GetNoteList) {
          noteList = state.noteList;
        } else if (state is UpdateState) {
          noteList = state.noteList;
        }

        return Column(
          children: [
            Expanded(
              child: noteList.isNotEmpty
                  ? getNoteListView(noteList)
                  : Center(
                      child: Text("Nenhum usuário"),
                    ),
            ),
          ],
        );
      },
    );
  }

  ListView getNoteListView(List<Note> noteList) {
    return ListView.builder(
      itemCount: noteList.length,
      itemBuilder: (context, position) => ListTile(
        leading: GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => UpdateScreen(note: noteList[position]),
              ),
            );
          },
          child: Icon(icons[position % icons.length]),
        ),
        trailing: GestureDetector(
          onTap: () {
            BlocProvider.of<ManageBloc>(context)
                .add(DeleteEvent(noteId: noteList[position].noteId));
            if (noteList.length == 1) {
              BlocProvider.of<ManageBloc>(context).add(EmptyListEvent());
            }
          },
          child: const Icon(Icons.delete),
        ),
        title: Text("Usuário"),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Email: ${noteList[position].email}"),
            Text("Senha: ${noteList[position].senha}"),
            Text("Senha Novamente: ${noteList[position].senhaNovamente}"),
            Text("Nome Completo: ${noteList[position].nomeCompleto}"),
            Text("CPF: ${noteList[position].cpf}"),
            Text("Data de Nascimento: ${noteList[position].dataNascimento}"),
          ],
        ),
      ),
    );
  }
}
