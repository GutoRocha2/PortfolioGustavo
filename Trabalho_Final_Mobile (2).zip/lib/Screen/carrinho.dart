import 'package:flutter/material.dart';
import 'nav.dart';

class CarrinhoScreen extends StatefulWidget {
  final List<String> itens;
  final List<double> valores;
  final double valorTotal;
  final Function(int) removerItem;

  CarrinhoScreen({
    Key? key,
    required this.itens,
    required this.valores,
    required this.valorTotal,
    required this.removerItem,
  }) : super(key: key);

  @override
  _CarrinhoScreenState createState() => _CarrinhoScreenState();
}

class _CarrinhoScreenState extends State<CarrinhoScreen> {
  late List<String> _itens;
  late List<double> _valores;
  ValueNotifier<double> _valorTotalNotifier = ValueNotifier<double>(0.0);

  @override
  void initState() {
    super.initState();
    _itens = List.from(widget.itens);
    _valores = List.from(widget.valores);
    _valorTotalNotifier.value = widget.valorTotal;
  }

  void _atualizarValorTotal() {
    _valorTotalNotifier.value = _valores.fold(0.0, (prev, curr) => prev + curr);
  }

  void _removerItem(int index) {
    if (index >= 0 && index < _itens.length) {
      setState(() {
        widget.removerItem(index); // Chama a função de remoção do widget pai
        _itens.removeAt(index);
        _valores.removeAt(index);
        _atualizarValorTotal();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow,
        title: Text(
          'Pedagógica',
          style: TextStyle(fontSize: 40, color: Colors.green),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              Text.rich(
                TextSpan(
                  children: [
                    TextSpan(
                      text: 'Itens no seu carrinho:\n',
                      style: TextStyle(fontSize: 30),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              ListView.builder(
                shrinkWrap: true,
                itemCount: _itens.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(_itens[index]),
                    trailing: IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () {
                        _removerItem(index);
                      },
                    ),
                  );
                },
              ),
              SizedBox(height: 30),
              SizedBox(
                width: 170,
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    print('Imprimir Boleto clicado!');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.amber,
                  ),
                  child: Text('Imprimir Boleto'),
                ),
              ),
              SizedBox(height: 10),
              SizedBox(
                width: 170,
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    print('Emitir nota fiscal clicado!');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    side: BorderSide(color: Colors.amber, width: 2),
                  ),
                  child: Text('Emitir nota fiscal'),
                ),
              ),
              SizedBox(height: 20),
              ValueListenableBuilder<double>(
                valueListenable: _valorTotalNotifier,
                builder: (context, valorTotal, _) {
                  return Text(
                    'Valor total: R\$ ${valorTotal.toStringAsFixed(2)}',
                    style: TextStyle(fontSize: 20),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
