// ignore_for_file: avoid_print

import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:trabalho_1_mobile/Screen/account_Screen.dart';
import 'package:trabalho_1_mobile/Screen/login_Screen.dart';
import 'package:trabalho_1_mobile/Screen/lista.dart';
import 'package:trabalho_1_mobile/Screen/loja.dart';
import 'package:trabalho_1_mobile/Screen/carrinho.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(
    title: 'Pedagógica',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      primarySwatch: Colors.amber,
    ),
    home: DrawerLayout(tela: 0),
  ));
}

class DrawerLayout extends StatefulWidget {
  final int tela;

  DrawerLayout({Key? key, required this.tela}) : super(key: key);

  @override
  _DrawerLayoutState createState() => _DrawerLayoutState();
}

class _DrawerLayoutState extends State<DrawerLayout> {
  int _currentScreen = 0;
  List<String> _itens = [];
  double _valorTotal = 0.0;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _currentScreen = widget.tela;
  }

  void changeScreen(int value) {
    setState(() {
      _currentScreen = value;
      Navigator.pop(context);
    });
  }

  void _atualizarCarrinho(List<String> itens, double valorTotal) {
    setState(() {
      _itens = itens;
      _valorTotal = valorTotal;
    });
  }

  @override
  Widget build(BuildContext context) {
    bool showAppBar = _currentScreen != 4;

    return Scaffold(
      key: _scaffoldKey,
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.green),
              child: Text("Telas"),
            ),
            ListTile(
              title: Text("Criar conta"),
              tileColor: Colors.yellow,
              onTap: () {
                changeScreen(0);
              },
            ),
            ListTile(
              title: Text("Fazer login"),
              tileColor: Colors.green,
              onTap: () {
                changeScreen(1);
              },
            ),
            ListTile(
              title: Text("Loja"),
              tileColor: Colors.yellow,
              onTap: () {
                changeScreen(2);
              },
            ),
            ListTile(
              title: Text("Lista de usuários"),
              tileColor: Colors.green,
              onTap: () {
                changeScreen(3);
              },
            ),
            ListTile(
              title: Text("Carrinho"),
              tileColor: Colors.yellow,
              onTap: () {
                changeScreen(4);
              },
            ),
          ],
        ),
      ),
      appBar: showAppBar
          ? AppBar(
              backgroundColor: Colors.yellow,
              title: Text(
                'Pedagógica',
                style: TextStyle(fontSize: 40, color: Colors.green),
              ),
              leading: IconButton(
                icon: Icon(Icons.menu),
                onPressed: () {
                  _scaffoldKey.currentState!.openDrawer();
                },
              ),
              automaticallyImplyLeading: false,
            )
          : null,
      body: IndexedStack(
        index: _currentScreen,
        children: [
          AccountScreen(),
          LoginScreen(),
          LojaScreen(),
          Lista(),
          CarrinhoScreen(
            itens: _itens,
            valorTotal: _valorTotal,
            valores: [],
            removerItem: (p0) {
              return;
            },
          ),
        ],
      ),
    );
  }
}
