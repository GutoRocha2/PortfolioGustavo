// ignore_for_file: prefer_const_constructors, library_private_types_in_public_api, file_names
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:trabalho_1_mobile/Model/note.dart';
import '../bloc/manage_bloc.dart';

class UpdateScreen extends StatelessWidget {
  const UpdateScreen({Key? key, required this.note}) : super(key: key);

  final Note note;

  static const String _title = 'Pedagógica';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow,
        title: Text(
          _title,
          style: TextStyle(fontSize: 40, color: Colors.green),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black, size: 30),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: MyHomePage(note: note),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.note}) : super(key: key);

  final Note note;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late Note note;
  String? email;
  String? senha;
  String? senhaNovamente;
  String? nomeCompleto;
  String? cpf;
  DateTime? dataNascimento;

  @override
  void initState() {
    super.initState();
    note = widget.note;
    email = note.email;
    senha = note.senha;
    senhaNovamente = note.senhaNovamente;
    nomeCompleto = note.nomeCompleto;
    cpf = note.cpf;
    dataNascimento = note.dataNascimento;
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: <Widget>[
                SizedBox(height: 30.0),
                Text(
                  'Email',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25),
                ),
                TextFormField(
                  initialValue: email,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.grey,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Coloque um email.';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    setState(() {
                      email = value;
                    });
                  },
                ),
                SizedBox(height: 10.0),
                Text(
                  'Senha',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25),
                ),
                TextFormField(
                  obscureText: true,
                  initialValue: senha,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.grey,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Coloque uma senha.';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    setState(() {
                      senha = value;
                    });
                  },
                ),
                SizedBox(height: 10.0),
                Text(
                  'Senha novamente',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25),
                ),
                TextFormField(
                  obscureText: true,
                  initialValue: senhaNovamente,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.grey,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Coloque sua mesma senha.';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    setState(() {
                      senhaNovamente = value;
                    });
                  },
                ),
                SizedBox(height: 10.0),
                Text(
                  'Nome Completo',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25),
                ),
                TextFormField(
                  initialValue: nomeCompleto,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.grey,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Coloque seu nome completo.';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    setState(() {
                      nomeCompleto = value;
                    });
                  },
                ),
                SizedBox(height: 10.0),
                Text(
                  'CPF',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25),
                ),
                TextFormField(
                  initialValue: cpf,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.grey,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Coloque seu CPF';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    setState(() {
                      cpf = value;
                    });
                  },
                ),
                SizedBox(height: 10.0),
                Text(
                  'Data de Nascimento',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25),
                ),
                TextFormField(
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.grey,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    labelText: dataNascimento != null
                        ? '${dataNascimento!.day}/${dataNascimento!.month}/${dataNascimento!.year}'
                        : ' ',
                  ),
                  readOnly: true,
                  onTap: () async {
                    FocusScope.of(context).requestFocus(FocusNode());
                    final DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime.now(),
                    );
                    if (pickedDate != null) {
                      setState(() {
                        dataNascimento = pickedDate;
                      });
                    }
                  },
                  validator: (value) {
                    if (dataNascimento == null) {
                      return 'Por favor, selecione uma data';
                    }
                    return null;
                  },
                  onSaved: (value) {
                    note.dataNascimento = dataNascimento!;
                  },
                ),
                SizedBox(height: 20.0),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                        note.email = email ?? '';
                        note.senha = senha ?? '';
                        note.senhaNovamente = senhaNovamente ?? '';
                        note.nomeCompleto = nomeCompleto ?? '';
                        note.cpf = cpf ?? '';
                        note.dataNascimento = dataNascimento ?? DateTime.now();
                        BlocProvider.of<ManageBloc>(context).add(
                          SubmitEvent(note: note, isUpdate: true),
                        );
                        _formKey.currentState!.reset();
                        Navigator.pop(context);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: Colors.green,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: BorderSide(color: Colors.white),
                      ),
                      minimumSize: Size(double.infinity, 60),
                    ),
                    child:
                        Text('Atualizar dados', style: TextStyle(fontSize: 25)),
                  ),
                ),
                SizedBox(height: 30.0),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
