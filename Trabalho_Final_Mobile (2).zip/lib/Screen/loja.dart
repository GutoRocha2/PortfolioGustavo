import 'package:flutter/material.dart';
import 'package:trabalho_1_mobile/Screen/carrinho.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pedagógica',
      home: LojaScreen(),
    );
  }
}

class LojaScreen extends StatefulWidget {
  @override
  _LojaScreenState createState() => _LojaScreenState();
}

class _LojaScreenState extends State<LojaScreen> {
  List<String> _itens = [];
  List<double> _valores = [];
  double _valorTotal = 0.0;

  void _atualizarCarrinho(String item, double valor) {
    setState(() {
      _itens.add(item);
      _valores.add(valor);
      _valorTotal += valor;
    });
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CarrinhoScreen(
          itens: _itens,
          valores: _valores,
          valorTotal: _valorTotal,
          removerItem: _removerItem,
        ),
      ),
    );
  }

  void _removerItem(int index) {
    setState(() {
      _valorTotal -= _valores[index];
      _itens.removeAt(index);
      _valores.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(
            height: 30,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Caderno Happy Landscape 20 Mat. 400 Folhas R\$28,21',
                      28.21);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Caderno.jpg'),
                      SizedBox(height: 10),
                      Text(
                        'Caderno Happy Landscape 20 Mat. 400 Folhas R\$:28,21',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Estojo 100 Pens-FreshPink-Kipling R\$450,00', 450.00);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Estojo.webp'),
                      SizedBox(height: 10),
                      Text(
                        'Estojo 100 Pens-FreshPink-Kipling R\$: 450,00',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 50),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Mochila Nike Elemental R\$350,00', 350.00);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Mochila.webp'),
                      SizedBox(height: 10),
                      Text(
                        'Mochila Nike Elemental R\$: 350,00',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Kit Lápis De Cor Faber-castell C/ 24 Cores R\$19,90',
                      19.90);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Lapis.webp'),
                      SizedBox(height: 10),
                      Text(
                        'Kit Lápis De Cor Faber-castell C/ 24 Cores R\$19,90',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 50),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho('Canetas tinteiro JINHAO R\$12,50', 12.50);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Canetas tinteiro.jfif'),
                      SizedBox(height: 10),
                      Text(
                        'Canetas tinteiro JINHAO R\$: 12,50',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Lapiseiras 0.7 mm escolar R\$27,55', 27.55);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Lapiseiras.jfif'),
                      SizedBox(height: 10),
                      Text(
                        'Lapiseiras 0.7 mm escolar R\$:27,55',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 50),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Canetinhas invisiveis 6 pçs R\$25,70', 25.70);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Canetinhas.jfif'),
                      SizedBox(height: 10),
                      Text(
                        'Canetinhas invisiveis 6 pçs R\$: 25,70',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Regua plástica geométrica 20 cm transp. R\$12,49',
                      12.49);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Regua.jfif'),
                      SizedBox(height: 10),
                      Text(
                        'Regua plástica geométrica 20 cm transp. R\$:12,49',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 50),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Kit Glitter Purpurina 12 Unidades R\$19,90', 19.90);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Purpurina.jfif'),
                      SizedBox(height: 10),
                      Text(
                        'Kit Glitter Purpurina 12 Unidades R\$:19,90',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Cola bastão Pritt 10g lavável atóxica R\$18,50', 18.50);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Cola.jfif'),
                      SizedBox(height: 10),
                      Text(
                        'Cola bastão Pritt 10g lavável atóxica R\$18,50',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 50),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Kit bic C/ 12 Cores + 3 Lapiserias 0.5 R\$18,50', 28.21);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Canetas e lapiseiras.jfif'),
                      SizedBox(height: 10),
                      Text(
                        'Kit bic C/ 12 Cores + 3 Lapiserias 0.5 R\$:18,50',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  _atualizarCarrinho(
                      'Kit material escolar completo Unissex R\$218,49',
                      218.49);
                },
                child: Container(
                  width: 170,
                  height: 250,
                  color: Colors.grey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/Kit completo.jfif'),
                      SizedBox(height: 10),
                      Text(
                        'Kit material escolar completo Unissex R\$218,49',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
