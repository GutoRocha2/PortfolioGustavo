// ignore_for_file: prefer_const_constructors, library_private_types_in_public_api, file_names
// ignore: depend_on_referenced_packages
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:trabalho_1_mobile/Screen/nav.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Firebase.initializeApp(
      options: FirebaseOptions(
          apiKey: 'AIzaSyD67g4wDj-XFXHzIxmlZ3lwurb7r28PtAM',
          appId: '1:260166649762:web:c16bea0f2ba90bfda2d4fb',
          messagingSenderId: '260166649762',
          projectId: 'trabalho-1-92856',
          authDomain: 'trabalho-1-92856.firebaseapp.com',
          storageBucket: 'trabalho-1-92856.appspot.com'));
  runApp(MaterialApp(
    title: 'Pedagógica',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      primarySwatch: Colors.amber,
    ),
    home: WelcomeScreen(),
  ));
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  static const String _title = 'Pedagógica';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.amber,
      ),
      home: const WelcomePage(),
    );
  }
}

class WelcomePage extends StatefulWidget {
  const WelcomePage({Key? key}) : super(key: key);

  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow,
        title: Text(
          'Pedagógica',
          style: TextStyle(fontSize: 40, color: Colors.green),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: 50.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/Lapis.png',
                  height: 40,
                ),
                SizedBox(width: 20),
                Image.asset(
                  'assets/Prancheta.png',
                  height: 40,
                ),
                SizedBox(width: 20),
                Image.asset(
                  'assets/clips.png',
                  height: 40,
                ),
              ],
            ),
            SizedBox(height: 50.0),
            Text(
              'Bem vindo a: ',
              style: TextStyle(fontSize: 30.0),
              textAlign: TextAlign.center,
            ),
            Text(
              'Pedagógica',
              style: const TextStyle(
                fontSize: 50,
                color: Colors.green,
              ),
            ),
            SizedBox(height: 50.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => DrawerLayout(tela: 1)),
                );
              },
              style: ButtonStyle(
                minimumSize: MaterialStateProperty.all<Size>(Size(250, 75)),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.amber),
                foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
                    EdgeInsets.all(12)),
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    side: BorderSide(color: Colors.amber, width: 1),
                  ),
                ),
                textStyle: MaterialStateProperty.all<TextStyle>(
                  TextStyle(fontSize: 30),
                ),
              ),
              child: Text('Fazer Login'),
            ),
            SizedBox(height: 30.0),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DrawerLayout(tela: 0)),
                  );
                });
              },
              style: ButtonStyle(
                minimumSize: MaterialStateProperty.all<Size>(Size(250, 75)),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
                foregroundColor: MaterialStateProperty.all<Color>(Colors.amber),
                padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
                    EdgeInsets.all(12)),
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    side: BorderSide(color: Colors.amber, width: 2),
                  ),
                ),
                textStyle: MaterialStateProperty.all<TextStyle>(
                  TextStyle(fontSize: 30),
                ),
              ),
              child: Text('Criar Conta'),
            ),
          ],
        ),
      ),
    );
  }
}
