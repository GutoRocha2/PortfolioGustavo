// ignore_for_file: prefer_const_constructors, prefer_initializing_formals, library_private_types_in_public_api, deprecated_member_use, file_names
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:trabalho_1_mobile/Model/note.dart';
import '../bloc/auth_bloc.dart';
import 'package:trabalho_1_mobile/Screen/loja.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({Key? key}) : super(key: key);

  static const String _title = 'Pedagógica';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      debugShowCheckedModeBanner: false,
      home: const MyHomePage(),
    );
  }
}

class Usuario {
  late String email;
  late String senha;
  late String senhaNovamente;
  late String nomeCompleto;
  late DateTime dataNascimento;
  late String cpf;
  Usuario({
    required String email,
    required String senha,
    required String senhaNovamente,
    required String nomeCompleto,
    required DateTime dataNascimento,
    required String cpf,
  }) {
    this.email = email;
    this.senha = senha;
    this.senhaNovamente = senhaNovamente;
    this.nomeCompleto = nomeCompleto;
    this.dataNascimento = dataNascimento;
    this.cpf = cpf;
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final Note note = Note();
  final List<Usuario> usuarios = [];
  String? email;
  String? senha;
  String? senhaNovamente;
  String? nomeCompleto;
  String? cpf;
  DateTime? dataNascimento;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: <Widget>[
                  SizedBox(height: 30.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        'assets/Lapis.png',
                        height: 40,
                      ),
                      SizedBox(width: 20),
                      Image.asset(
                        'assets/Prancheta.png',
                        height: 40,
                      ),
                      SizedBox(width: 20),
                      Image.asset(
                        'assets/clips.png',
                        height: 40,
                      ),
                    ],
                  ),
                  SizedBox(height: 20.0),
                  Text(
                    'Email',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25),
                  ),
                  TextFormField(
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Coloque um email.';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      setState(() {
                        email = value;
                      });
                    },
                  ),
                  SizedBox(height: 10.0),
                  Text(
                    'Senha',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25),
                  ),
                  TextFormField(
                    obscureText: true,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Coloque uma senha.';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      setState(() {
                        senha = value;
                      });
                    },
                  ),
                  SizedBox(height: 10.0),
                  Text(
                    'Senha novamente',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25),
                  ),
                  TextFormField(
                    obscureText: true,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Coloque sua mesma senha.';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      setState(() {
                        senhaNovamente = value;
                      });
                    },
                  ),
                  SizedBox(height: 10.0),
                  Text(
                    'Nome Completo',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25),
                  ),
                  TextFormField(
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Coloque seu nome completo.';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      setState(() {
                        nomeCompleto = value;
                      });
                    },
                  ),
                  SizedBox(height: 10.0),
                  Text(
                    'CPF',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25),
                  ),
                  TextFormField(
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Coloque seu CPF';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      setState(() {
                        cpf = value;
                      });
                    },
                  ),
                  SizedBox(height: 10.0),
                  Text(
                    'Data de Nascimento',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25),
                  ),
                  TextFormField(
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      labelText: dataNascimento != null
                          ? '${dataNascimento!.day}/${dataNascimento!.month}/${dataNascimento!.year}'
                          : ' ',
                    ),
                    readOnly: true,
                    onTap: () async {
                      FocusScope.of(context).requestFocus(FocusNode());
                      final DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(1900),
                        lastDate: DateTime.now(),
                      );
                      if (pickedDate != null) {
                        setState(() {
                          dataNascimento = pickedDate;
                        });
                      }
                    },
                    validator: (value) {
                      if (dataNascimento == null) {
                        return 'Por favor, selecione uma data';
                      }
                      return null;
                    },
                    onSaved: (value) {
                      note.dataNascimento = dataNascimento!;
                    },
                  ),
                  SizedBox(height: 20.0),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        _usuarioCriado(context);
                        if (_formKey.currentState!.validate()) {
                          _formKey.currentState!.save();
                          note.email = email!;
                          note.senha = senha!;
                          note.senhaNovamente = senhaNovamente!;
                          note.nomeCompleto = nomeCompleto!;
                          note.cpf = cpf!;
                          note.dataNascimento = dataNascimento!;
                          BlocProvider.of<AuthBloc>(context)
                              .add(RegisterUser(note: note));
                          _formKey.currentState!.reset();
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (context) => LojaScreen()),
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(color: Colors.white),
                        ),
                        minimumSize: Size(double.infinity, 60),
                      ),
                      child:
                          Text('Criar Conta', style: TextStyle(fontSize: 25)),
                    ),
                  ),
                  SizedBox(height: 30.0),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _exibirSnackBar(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          "O Usuário foi cadastrado! "
          "Email: $email\n"
          "Senha: $senha\n"
          "Senha Novamente: $senhaNovamente\n"
          "Nome Completo: $nomeCompleto\n"
          "CPF: $cpf\n"
          "Data de Nascimento: $dataNascimento",
          style: TextStyle(fontSize: 18),
          textAlign: TextAlign.center,
        ),
        duration: Duration(seconds: 5),
      ),
    );
  }

  void _usuarioCriado(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          "O Usuário foi cadastrado!",
          style: TextStyle(fontSize: 18),
          textAlign: TextAlign.center,
        ),
        duration: Duration(seconds: 5),
      ),
    );
  }
}
