// ignore_for_file: avoid_print
import 'package:flutter_bloc/flutter_bloc.dart';
import '../Model/note.dart';
import '../Provider/rest_provider.dart';

class ManageBloc extends Bloc<ManageEvent, ManageState> {
  ManageBloc() : super(InsertState(noteList: [])) {
    on<SubmitEvent>((event, emit) async {
      try {
        if (event.isUpdate) {
          await RestProvider.helper.updateNote(event.note.noteId, event.note);
        } else {
          await RestProvider.helper.insertNote(event.note);
        }
        List<Note> noteList = await RestProvider.helper.getNoteList();
        emit(InsertState(noteList: noteList));
      } catch (e) {
        print('Erro ao submeter nota: $e');
      }
    });

    on<DeleteEvent>((event, emit) async {
      await RestProvider.helper.deleteNote(event.noteId);
      List<Note> noteList = await RestProvider.helper.getNoteList();
      emit(InsertState(noteList: noteList));
    });

    on<GetNoteList>((event, emit) async {
      List<Note> noteList = await RestProvider.helper.getNoteList();
      emit(InsertState(noteList: noteList));
    });

    on<EmptyListEvent>((event, emit) {
      emit(InsertState(noteList: []));
    });

    on<UpdateRequest>((event, emit) {
      emit(UpdateState(
        noteId: event.noteId,
        noteList: state.noteList,
      ));
    });

    on<UpdateCancel>((event, emit) {
      emit(InsertState(
        noteList: state.noteList,
      ));
    });
  }
}

abstract class ManageEvent {}

class SubmitEvent extends ManageEvent {
  Note note;
  final bool isUpdate;
  SubmitEvent({required this.note, this.isUpdate = false});
}

class UpdateEvent extends ManageEvent {
  String noteId;
  Note note;
  UpdateEvent({required this.noteId, required this.note});
}

class DeleteEvent extends ManageEvent {
  String noteId;
  DeleteEvent({required this.noteId});
}

class GetNoteList extends ManageEvent {}

class UpdateRequest extends ManageEvent {
  String noteId;
  UpdateRequest({required this.noteId});
}

class UpdateCancel extends ManageEvent {}

class EmptyListEvent extends ManageEvent {}

abstract class ManageState {
  List<Note> noteList;

  ManageState({required this.noteList});
}

class InsertState extends ManageState {
  InsertState({required super.noteList});
}

class UpdateState extends ManageState {
  String noteId;
  UpdateState({
    required this.noteId,
    required super.noteList,
  });
}
