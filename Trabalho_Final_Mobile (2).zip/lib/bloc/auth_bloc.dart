import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:trabalho_1_mobile/Model/note.dart';
import 'package:trabalho_1_mobile/Provider/rest_provider.dart';

/*
   Eventos
*/
abstract class AuthEvent {}

class RegisterUser extends AuthEvent {
  final Note note;

  RegisterUser({required this.note});
}

class LoginUser extends AuthEvent {
  final String username;
  final String password;

  LoginUser({required this.username, required this.password});
}

class LoginAnonymousUser extends AuthEvent {}

class Logout extends AuthEvent {}

class AuthServerEvent extends AuthEvent {
  final String? userModel;

  AuthServerEvent(this.userModel);
}

/*
   Estados
*/
abstract class AuthState {}

class Unauthenticated extends AuthState {}

class Authenticated extends AuthState {
  final String userModel;

  Authenticated({required this.userModel});
}

class AuthError extends AuthState {
  final String message;

  AuthError({required this.message});
}

/*
   Bloc
*/
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  AuthBloc() : super(Unauthenticated()) {
    on<AuthServerEvent>((event, emit) {
      if (event.userModel == null) {
        RestProvider.helper.uid = "public";
        emit(Unauthenticated());
      } else {
        RestProvider.helper.uid = event.userModel!;
        emit(Authenticated(userModel: event.userModel!));
      }
    });

    on<RegisterUser>((event, emit) async {
      try {
        RestProvider.helper.insertNote(event.note);
        emit(Authenticated(userModel: event.note.email));
      } catch (e) {
        RestProvider.helper.uid = "public";
        emit(AuthError(message: "Impossível Registrar: ${e.toString()}"));
      }
    });

    on<LoginUser>((event, emit) async {
      try {
        emit(Authenticated(userModel: event.username));
      } catch (e) {
        RestProvider.helper.uid = "public";
        emit(AuthError(
            message:
                "Impossível Logar com ${event.username}: ${e.toString()}"));
      }
    });

    on<Logout>((event, emit) async {
      try {
        emit(Unauthenticated());
      } catch (e) {
        RestProvider.helper.uid = "public";
        emit(AuthError(message: "Impossível Efetuar Logout: ${e.toString()}"));
      }
    });
  }
}
