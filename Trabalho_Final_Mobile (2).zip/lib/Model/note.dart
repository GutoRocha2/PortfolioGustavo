// ignore_for_file: prefer_const_constructors

class Note {
  late String email;
  late String senha;
  late String senhaNovamente;
  late String nomeCompleto;
  late String cpf;
  late DateTime dataNascimento;
  String noteId = "";

  Note() {
    email = "";
    senha = "";
    senhaNovamente = "";
    nomeCompleto = "";
    dataNascimento = DateTime(0000, 00, 00);
    cpf = "cpf";
  }

  Note.withData({
    this.email = "",
    this.senha = "",
    this.senhaNovamente = "",
    this.nomeCompleto = "",
    this.cpf = "",
  }) {
    dataNascimento = DateTime.now().subtract(Duration(days: 18 * 365));
  }

  Note.fromMap(map) {
    email = map["email"];
    senha = map["senha"];
    senhaNovamente = map["senhaNovamente"];
    nomeCompleto = map["nomeCompleto"];
    cpf = map["CPF"];
    dataNascimento = DateTime.parse(map["dataNascimento"]);
  }

  toMap() {
    var map = <String, dynamic>{};
    map["email"] = email;
    map["senha"] = senha;
    map["senhaNovamente"] = senhaNovamente;
    map["nomeCompleto"] = nomeCompleto;
    map["CPF"] = cpf;
    map["dataNascimento"] = dataNascimento.toIso8601String();
    return map;
  }
}
